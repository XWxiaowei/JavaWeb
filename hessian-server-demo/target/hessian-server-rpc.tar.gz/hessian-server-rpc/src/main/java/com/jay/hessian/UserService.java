package com.jay.hessian;

/**
 * Created by xiang.wei on 2018/2/10
 *
 * @author xiang.wei
 */
public interface UserService {

    /**
     * 返回用户传入的名称
     * @param user
     * @return
     */
    String sayMyName(User user);
}
